<?php
if( !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' );

/**
*
* @package VirtueMart
* @subpackage EU Recapitulative Statement
* @copyright Copyright (C) 2015 Open Tools, Reinhold Kainhofer.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
*
* http://www.open-tools.net
*/

$from_month=date("Y-m", $this->from);
$until_month=date("Y-m", $this->until);
if ($this->settings['frequency']==1) {
	// monthly
	$month=date("m", $this->from);
	$quarter='';
} else {
	// quarterly (there is no yearly reporting in SK)
	$month='';
	$romans=array("I", "II", "III", "IV");
	$quarter = $romans[(date("m", $this->from)-1)/3];
}

$vatid = $this->settings['vendor_vatid'];
$vatid = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($vatid)));

$vend = $this->vendor;


header("Content-Type: text/xml");
header("Content-Disposition: attachment; filename=\"EU_Recap_Statement_${from_month}_${until_month}.SK.xml\"");

echo "Vendor: ";
print_r($vend);
?><?php
foreach ($this->report as $r) { 
	$vatid = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($r['vatid'])));
?>
		<ZM>
			<UID_MS><?php echo $vatid; ?></UID_MS>
			<SUM_BGL type="kz"><?php echo $r['sum_order_total']; ?></SUM_BGL>
<?php //			<DREIECK>0</DREIECK> ?>
			<SOLEI>1</SOLEI>
		</ZM>
<?php 
} 
?>

<?xml version="1.0" encoding="UTF-8"?>
<dokument xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="universal.xsd">
<hlavicka>
	<identifikacneCislo>
		<kodStatu><?php echo substr($vatid, 0, 2); ?></kodStatu>
		<dic><?php echo substr($vatid, 2); ?></dic>
	</identifikacneCislo>
	<danovyUrad>Rimavská Sobota</danovyUrad>
	<druhSV>
		<riadny>1</riadny>
		<opravny>0</opravny>
		<dodatocny>0</dodatocny>
	</druhSV>
	<obdobie>
		<mesiac><?php echo $month ?></mesiac>
		<stvrtrok><?php echo $quarter ?></stvrtrok>
		<rok><?php echo date("Y", $this->from); ?></rok>
	</obdobie>
	<obchodneMeno>
		<riadok>RuposTel s. r. o.</riadok>
		<riadok></riadok>
		<riadok></riadok>
		<riadok></riadok>
	</obchodneMeno>
	<adresa>
		<ulica>Sídlisko Rimava 1069</ulica>
		<cislo>36</cislo>
		<psc>97901</psc>
		<obec>Rimavská Sobota 1</obec>
		<tel>
			<predcislie>047</predcislie>
			<cislo>5811050</cislo>
		</tel>
		<fax>
			<predcislie></predcislie>
			<cislo></cislo>
		</fax>
	</adresa>
	<celkovaHodnota>3654</celkovaHodnota>
	<pocet2Stran>3</pocet2Stran>
	<konatel>Stanislav Scholtz</konatel>
	<konatelTel>
		<predcislie></predcislie>
		<cislo>0908714306</cislo>
	</konatelTel>
	<datumVyhlasenia>
		<den><?php echo date("d"); ?></den>
		<mesiac><?php echo date("m"); ?></mesiac>
		<rok><?php echo date("Y"); ?></rok>
	</datumVyhlasenia>
</hlavicka>
<telo>
	<strana>
		<oznacenie>
			<aktualna>1</aktualna>
			<celkovo>3</celkovo>
		</oznacenie>
		<zaznam>
			<kodStatu>AT</kodStatu>
			<idCislo>U60538458</idCislo>
			<hodnota>49</hodnota>
			<kod>2</kod>
		</zaznam>
		<zaznam>
			<kodStatu>BE</kodStatu>
			<idCislo>897016705</idCislo>
			<hodnota>49</hodnota>
			<kod>2</kod>
		</zaznam>
		<!-- Always group 27 entries per page; Fill with empty <zaznam/> tags if neccessary -->
	</strana>
	<strana>
		<oznacenie>
			<aktualna>3</aktualna>
			<celkovo>3</celkovo>
		</oznacenie>
		<zaznam>
			<kodStatu></kodStatu>
			<idCislo></idCislo>
			<hodnota></hodnota>
			<kod></kod>
		</zaznam>
		<zaznam>
			<kodStatu></kodStatu>
			<idCislo></idCislo>
			<hodnota></hodnota>
			<kod></kod>
		</zaznam>
	</strana>
</telo>
</dokument>
